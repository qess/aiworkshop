# Copyright (C) Siemens AG 2021. All Rights Reserved. Confidential.

"""
Helpers.

This module contains functionality that does not belong to the main domain of the `simaticai` module.


"""
