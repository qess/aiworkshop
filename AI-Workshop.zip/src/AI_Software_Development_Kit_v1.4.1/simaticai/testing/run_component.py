# Copyright (C) Siemens AG 2021. All Rights Reserved. Confidential.

"""
Utility script for running an `entrypoint` Python script in a given virtual Python environment.
It is designed to be executed from `simaticai.testing.PipelineRunner` class.
It consumes input data from a joblib file and produces output data into a joblib file.
"""

import os
import sys
import json
import joblib
import argparse
import logging
import importlib
import inspect


logging.basicConfig()
_logger = logging.getLogger(__name__)
_logger.setLevel(logging.INFO)

_parser = argparse.ArgumentParser()
_parser.add_argument("-m", "--module-name", type=str, help="The module which is implemented in the entrypoint Python script.")
_parser.add_argument("-i", "--input-file", type=str, help="The file which contains input data to test with component.")
_parser.add_argument("-o", "--output-file", type=str, help="The file which contains calculated output data.")
_parser.add_argument("-ll", "--log-level", default="INFO", type=str, help="Log Level using `logging` class' enum values.")
_parser.add_argument("-p", "--pipeline-parameters", type=str, help="Dict of configurable parameters with their values")


def main(module_name, input_file, output_file, pipeline_parameters:dict):
    """
    Feeds input to the entrypoint and captures output.

    Imports entrypoint module given with its name, and triggers its `run(...)` function with the prepared data in the input file.
    If pipeline_parameters dictionary is not empty, before triggering `run(..)` method, the `update_parameters(..)` method of entrypoint will be called with the dictionary.
    The input file must be a joblib dump, and the joblib must be a dictionary or list of dictionaries.
    One dictionary represents one input for the component with the required variable names and values, which is directly passed to `run()`.
    The output file is a dumped joblib result which is a list containing outputs of the component, in the structure returned from `run()`.

    Args:
        module_name (str): Name of the entrypoint Python script
        input_file (os.Pathlike): Path of the joblib file containing the input payloads
        output_file (os.Pathlike): Path of the joblib file where the outputs will be stored
        pipeline-parameters (json-string): json formatted dictionary defining configurable parameters with their names as key and their values
    """
    entrypoint = importlib.import_module(module_name)
    trigger_method = "none"

    try:
        inspect.signature(entrypoint.process_input)
        trigger_method = "process_input"
    except AttributeError:
        try:
            inspect.signature(entrypoint.run)
            trigger_method = "run"
        except AttributeError:
            _logger.warn("Method run not found")

    if trigger_method == "none":
        raise RuntimeError("Neither 'run(data: str)' nor 'process_input(data: dict)' entrypoint method can be found.")

    # configure Pipeline parameters
    if pipeline_parameters:
        _logger.debug(f"Entrypoint `update_parameters(..)` to be called with: {pipeline_parameters}")
        entrypoint.update_parameters(pipeline_parameters)

    input_list = joblib.load(input_file)
    input_list = input_list if type(input_list) == list else [input_list]

    output_list = []
    for input_data in input_list:
        assert type(input_data) == dict, "Input data must be a dictionary containing the input variables."

        if trigger_method == "process_input":
            _logger.debug("Entrypoint `process_input(..)` method has been called")
            output_list.append(entrypoint.process_input(input_data))
        else:
            _logger.debug("Entrypoint `run(..)` method has been called")
            output_list.append(entrypoint.run(json.dumps(input_data)))
            trigger_method = "run"

    joblib.dump(output_list, output_file)

    if trigger_method == "process_input":
        return 0
    else:
        _logger.warn("Trigger method `run(data: str)` is deprecated and will be removed in the future. Please refer the user manual.")
        return 0b10001  # binary return code means deprecated run method was triggered


if __name__ == '__main__':

    _args = _parser.parse_args()
    _logger.setLevel(logging.getLevelName(_args.log_level))

    _logger.info(f"arguments: \t {_args}")
    _logger.info(f"workdir: \t {os.path.abspath('.')}")

    sys.exit(main(_args.module_name, _args.input_file, _args.output_file, json.loads(_args.pipeline_parameters)))
