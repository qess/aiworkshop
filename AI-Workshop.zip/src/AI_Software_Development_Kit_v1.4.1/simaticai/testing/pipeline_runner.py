# Copyright (C) Siemens AG 2021. All Rights Reserved. Confidential.

"""
A pipeline runner that lets you simulate the execution of a pipeline in a local Python environment.

It can be used to locally mimic the behavior of the AI Inference Server concerning loading and running inference pipelines.
This is a quick and easy way to find programming or configuration errors before deploying the package.
The local pipeline runner also lets you exercise your pipeline component by component. In other words, you can feed
single components with inputs and verify the output produced.
"""

import tempfile
import zipfile
import yaml
import joblib
import json
import venv
import subprocess
import logging
import datetime
import sys
import os
import re
import shutil
from pathlib import Path

from importlib import metadata as importlib_metadata

from simaticai.testing.pipeline_validator import INVALID_PIPELINE_PACKAGE_MESSAGE

RETURN_CODE_OK = 0b0
RETURN_CODE_DEPRECATED = 0b10001  # equals to 17

logging.basicConfig()
_logger = logging.getLogger(__name__)
_logger.setLevel(logging.INFO)

_runner_path = Path(__file__).parent
_missing_variable_error_message = "Required variable '{name}' is missing from input for component '{component}'."

type_map = {
    'int': 'Integer',
    'float': 'Double',
    'bool': 'Boolean',
    'str': 'String'
}


class LocalPipelineRunner:
    """
    Simulates the execution of a pipeline in a local Python environment.

    Only works with a pipeline configuration package. Does not work with e.g. an edge configuration package.

    Restriction: only linear pipelines are supported where the pipeline input variables are only used by one component,
    each component uses only the outputs of the previous components, and the pipeline output only consists of variables from the last component.

    If the caller specifies no `path`, the working directory is temporary and is removed unless an error occurs.
    If the caller specifies a working directory with a `path` argument, the working directory is kept.
    This behavior can be overridden using boolean parameter `cleanup`.

    Currently, the pipeline runner supports both the current `process_input(data: dict)` entrypoint signature and the legacy
    `run(data: str)` signature. If both entrypoints are present, `process_input()` takes precedence. Please note however that
    `run()` is deprecated, and support for it will be removed in future versions of the pipeline runner.

    Args:
        packageZip (path-like): Path to the pipeline configuration package.
        path (path-like): Path to the working directory. If unset, a temporary directory is created.
        cleanup (bool): If set, the working directory is kept when True, and deleted when False. \
            If unset, a temporary working directory is removed, and an explicit working directory is kept. \
            When an error occurs in a component, the working directory is kept regardless of this value.
    """

    def __init__(self, packageZip: os.PathLike, path: os.PathLike = None, cleanup: bool = None):
        """
        Creates a new component LocalPipelineRunner for the provided pipeline configuration package.

        Only works with a pipeline configuration package. Does not work with e.g. an edge configuration package.

        Args:
            packageZip (path-like): Path to the pipeline configuration package.
            path (path-like): Path to the working directory. If unset a temporary directory will be created.
            cleanup (bool): If set, the working directory will be kept when True, and deleted when False. \
                If unset, a temporary working directory will be removed, and an explicit working directory will be kept. \
                When an error occurs in a component, the working directory will be kept regardless of this value.
        """
        self.components = {}
        self.parameters = {}
        self.package_zip = packageZip
        self.path = path
        self.cleanup = cleanup
        self.log_level = logging.INFO

    def __enter__(self):
        timestamp = re.sub(r"[-:]", "", datetime.datetime.utcnow().isoformat(sep="_", timespec="seconds"))
        if self.path is not None:
            self.workdir = Path(self.path)
            self.workdir.mkdir(parents=True, exist_ok=True)
            self.cleanup = self.cleanup if self.cleanup is not None else False
        else:
            self.workdir = Path(tempfile.mkdtemp(prefix=f"LocalPipelineRunner_{timestamp}_"))
            self.cleanup = self.cleanup if self.cleanup is not None else True

        with zipfile.ZipFile(self.package_zip) as zf:
            zf.extractall(path=self.workdir)
            self.workdir = self.workdir / zf.namelist()[0]

        try:
            with open(self.workdir / "pipeline_config.yml") as cf:
                config = yaml.load(cf, Loader=yaml.FullLoader)

            self.component_names = []
            for component in config["dataFlowPipeline"]["components"]:
                component["context"] = None
                component["env_dir"] = self.workdir / component['name']
                self.components[component["name"]] = component
                self.component_names.append(component["name"])

            for parameter in config["dataFlowPipeline"].get("pipelineParameters", {}):
                self.parameters[parameter["name"]] = parameter

        except Exception:
            raise RuntimeError(INVALID_PIPELINE_PACKAGE_MESSAGE)

        return self

    def __exit__(self, exception_type, value, traceback):
        if self.cleanup:
            _logger.info("Removing local pipeline runner environment...")
            shutil.rmtree(self.workdir.parent)
        else:
            _logger.info(f"Leaving local pipeline runner environment in its final state at '{self.workdir}'")

    def _set_log_level(self, log_level: int):
        self.log_level = log_level
        _logger.setLevel(self.log_level)

    def _init_component_venv(self, component: dict):
        """
        Creates a virtual environment in which the given component can run.

        Args:
            component (str): name of the selected component.
        """
        _logger.info(f"Creating virtual environment for component '{component['name']}'...")
        context_dir = component["env_dir"] / ".venv"
        builder = venv.EnvBuilder(with_pip=True)
        builder.create(str(context_dir))
        component["context"] = builder.ensure_directories(context_dir)
        component["bin_path"] = Path(component["context"].bin_path).absolute()
        _logger.debug("Component bin path: {component['bin_path']}")

        try:
            result = self._install_logmodule(component["bin_path"], component["env_dir"])
        except Exception:
            self.cleanup = False
            raise RuntimeError("The 'simaticai' Python package is either not installed or does not contain package 'log_module'.") from None
        if result.returncode != 0:
            self.cleanup = False
            raise RuntimeError(f"Error installing log_module:\n{result.stderr}")

        cmd = [f"{component['bin_path'] / 'python'}", "-m", "pip", "install", "--no-python-version-warning", "--no-warn-script-location", "-r", "requirements.txt"]

        package_dir = component["env_dir"] / "PythonPackages"
        package_zip = component["env_dir"] / "PythonPackages.zip"
        if package_zip.is_file():
            _logger.info("Extracting PythonPackages.zip")
            with zipfile.ZipFile(package_zip) as zf:
                zf.extractall(path=package_dir.absolute())
            cmd += ["-f", str(package_dir.absolute())]
        else:
            _logger.info("There is no PythonPackages.zip to extract.")

        if Path(component["env_dir"] / "requirements.txt").is_file():
            _logger.info("Installing requirements...")
            result = subprocess.run(cmd, cwd=component["env_dir"], text=True, stderr=subprocess.PIPE)
            if result.returncode != 0:
                self.cleanup = False
                raise RuntimeError(f"Error installing requirements:\n{result.stderr}")
        else:
            _logger.info("'requirements.txt' was not found. No additional dependencies were installed.")

    @staticmethod
    def _install_logmodule(bin_path, env_dir):
        _logger.info("Installing LogModule...")
        sdk_resources = importlib_metadata.files("simaticai")
        logger_wheel = [p for p in sdk_resources if 'log_module' in str(p)][0]
        cmd = [f"{bin_path / 'pip'}", "install", "--no-python-version-warning", "--no-warn-script-location", logger_wheel.locate(), "joblib"]
        return subprocess.run(cmd, cwd=env_dir, text=True, stderr=subprocess.PIPE)

    def run_component(self, name: str, data: list or dict):
        """
        Runs the component in its virtual environment with the given input.
        This environment is created according to `requirements.txt` in the package.
        Additionally 'joblib' and the mock `log_module` is automatically installed in this virtual environment.
        The input data can be a single input record in a dictionary or a batch of input records in a list of dictionaries.
        The supplied input data is saved as `inputs.joblib` in the component runtime directory, and the output is saved as `output.joblib`.

        Args:
            name (str): The name of the component to be executed.
            data (dict or list): One or more input records for the component.

        Returns:
            dict/list:   For a single record as input, the output record as a dictionary if there were no errors and the field `ready` is true, `None` otherwise. \
            For a list as input, a list of dictionaries for outputs if there were no errors and field `ready` is true.

        """
        assert name in self.components, f"Invalid component name: {name}"
        component = self.components[name]

        assert component["runtime"]["type"] == "python", f"Can not run component '{name}': runtime type is not 'python'"

        component_version = str(component["runtime"]["version"])
        system_version = re.match(r"^[\d.]+", sys.version)[0]
        if component_version.split('.')[:2] != system_version.split('.')[:2]:
            _logger.warning(f"Python version {system_version} will be used for running component {name} requiring Python version {component_version}")  # noqa: E701

        assert data is not None, f"Can not run component '{name}' without input."

        assert type(data) in (dict, list), "Input data must be a dict or list of dictionaries"
        if type(data) is list:
            assert len(data) > 0, "There is no data in input list."
            assert all(True if type(d) is dict else False for d in data), "Input data must contain dictionaries."

        for variable in component["inputType"]:
            if type(data) is list:
                assert all(True if variable["name"] in d else False for d in data), _missing_variable_error_message.format(name=variable["name"], component=name)
            else:
                _logger.info(f"{variable['name']}")
                assert variable["name"] in data, _missing_variable_error_message.format(name=variable["name"], component=name)

        if not component["context"]:
            self._init_component_venv(component)
            shutil.copy(_runner_path / 'run_component.py', component["env_dir"])

        module = Path(component["entrypoint"]).stem

        data_message = f"Feeding component '{name}' with input {data}"
        if len(data_message) > 256:
            data_message = f"'{data_message[:240]}...' (truncated)"
        _logger.info( data_message )

        joblib.dump(data, component["env_dir"] / "input.joblib")

        cmd = [f"{component['bin_path'] / 'python'}",
               "-m", 'run_component',
               "-m", module,
               "-i", "input.joblib",
               "-o", "output.joblib",
               "-p", self._get_pipeline_parameters(),
               "-ll", logging.getLevelName(self.log_level)]

        result = subprocess.run(cmd, cwd=component["env_dir"], text=True, stderr=subprocess.PIPE)
        if result.returncode not in [RETURN_CODE_OK, RETURN_CODE_DEPRECATED]:
            self.cleanup = False
            raise RuntimeError(f"There was an error while running component '{name}'.\n"
                               f"You can check the test results in directory {component['env_dir']}\n"
                               f"Error from component:\n {result.stderr}\n")
        else:
            response_wrapped = True if result.returncode == RETURN_CODE_DEPRECATED else False
            _logger.info(result.stderr)

        output_list = joblib.load(component["env_dir"] / "output.joblib")
        validate_object_output(output_list)

        if type(data) is list:  # input is a list of dictionaries -> output must be a list
            if response_wrapped:
                return [json.loads(output['output']) for output in output_list if output['ready']]
            else:
                return [output for output in output_list if output is not None]
        else:  # input is a dictionary -> output must be a dictionary or None
            if response_wrapped:
                if output_list[0]['ready'] is False:
                    return None
                else:
                    return json.loads(output_list[0]['output'])
            else:
                return output_list[0]

    def _get_pipeline_parameters(self):
        parameter_list = [(param["name"], param["defaultValue"]) for param in self.parameters.values()]
        return json.dumps(dict(parameter_list))

    def update_parameters(self, parameters: dict):
        """
        Validates and updates pipeline parameters.
        The elements of the dictionary must match the parameters specified in the pipeline configuration package.
        If any of the names or types does not match, all parameters will remain untouched.

        Args:

            parameters (dict): names and values of parameters to update

        Raises:

            AssertionError:
                When:
                - either `name` is not in the configured parameters,
                - or `defaultValue` type is different from the configured one
        """

        for key,value in parameters.items():
            if key not in self.parameters.keys() or self.parameters[key]["type"] != type_map.get(type(value).__name__):
                raise AssertionError(f"Pipeline has no parameters with the name '{key}' and type '{type_map.get(type(value).__name__)}'")

        for key, value in parameters.items():
            self.parameters[key]["defaultValue"] = value

    def run_pipeline(self, payload: dict or list):
        """
        Runs all the components sequentially, assuming the output of a component is only consumed by the next.
        The input data can be a single input record in a dictionary or a batch of input records in a list of dictionaries.
        For each component the supplied input data is saved as `input.joblib` in the component runtime directory,
        and the output is saved as `output.joblib`.

        Args:
            payload (dict or list): One or more input records for the pipeline.

        Returns:
            list: The outputs of the last component as a list of dictionaries. Includes only outputs if there were \
            no errors and field `ready` is true.
        """
        for name in self.component_names:
            payload = self.run_component(name, payload)
            assert payload is not None, f"Component '{name}' did not return any output."
        return payload


def validate_object_output(output_list):
    for output in output_list:
        if output is None:
            continue
        for key, value in output.items():
            if type(value) is dict:
                values = list(value.values())
                if len(value) != 2 \
                or type(values[0]) == type(values[1]) \
                or any(True for value in values if type(value) not in [str, bytes]):  # noqa: E721, E122
                    raise AttributeError(f"Invalid output field '{key}': Output of type Object must consist of one 'str' and one 'bytes' field.")
