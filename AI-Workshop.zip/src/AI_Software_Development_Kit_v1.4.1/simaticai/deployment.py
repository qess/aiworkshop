# Copyright (C) Siemens AG 2021. All Rights Reserved. Confidential.

"""
Packaging ML models for deployment on the AI Inference Server.

The AI SDK offers the functionality to create a pipeline configuration package and wrap trained models, which can be converted to an
edge configuration package and then uploaded and run on an AI Inference Server on an Industrial Edge device.

​From a deployment perspective, the inference pipeline can consist of one or more components. This is independent of the logical structure of
the inference pipeline. For example, a typical time series pipeline that consists of multiple Scikit Learn pipeline elements can be packaged
into a single pipeline component, which includes both a feature extractor and a classifier. Alternatively, you can deploy the same pipeline
split into two components, one for the feature extractor and another for the classifier.

To keep things simple and less error-prone, a pipeline should have as few components as possible.
In many cases, a single component will be sufficient.
However, there might be reasons why you might consider using separate components, such as:

- You need a different Python environment for different parts of your processing, e.g., you have components requiring conflicting package versions.
- You want to exploit parallelism between components without implementing multithreading.
- You want to modularize and build your pipeline from a pool of component variants, which you can combine flexibly.

The AI SDK allows you to create pipeline components implemented in Python and compose linear pipelines of one or multiple of such components.
The API is designed to anticipate future possible types of components that might be based on a different technology than Python, e.g. ONNX or
native TensorFlow Serving. Currently, only Python is supported.

For a comprehensive overview on how to package ML models in the context of a machine learning workflow, we recommend you refer to
the AI SDK User Manual, especially the chapter concerning packaging models into an inference pipeline. We also recommend you
follow the project templates for the AI SDK, which provide packaging notebooks as examples, and where source code and
saved trained models are organized into a given folder structure.

"""

import hashlib
import json
import logging
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime
from importlib import resources as module_resources
from pathlib import Path, PurePath

import cloudpickle as pickle
import joblib
import jsonschema
import jsonschema.exceptions
import yaml
from MarkupPy import markup
from simaticai.helpers import pep508, tempfiles, yaml_helper

logging.basicConfig()
logging.getLogger().handlers = [logging.StreamHandler(sys.stdout)]
_logger = logging.getLogger(__name__)
_logger.setLevel(logging.INFO)

_version_matcher = re.compile('Version: ([^ ]+).*')
_transitive_matcher = re.compile('Requires: (.+)')

_README_HTML = "README.html"

# https://www.python.org/dev/peps/pep-0440#appendix-b-parsing-version-strings-with-regular-expressions
_VERSION_REGEXP = r'([1-9][0-9]*!)?(0|[1-9][0-9]*)(\.(0|[1-9][0-9]*))*((a|b|rc)(0|[1-9][0-9]*))?(\.post(0|[1-9][0-9]*))?(\.dev(0|[1-9][0-9]*))?'

PYTHON_PACKAGES_ZIP = "PythonPackages.zip"
PIPELINE_CONFIG = "pipeline_config.yml"
DATALINK_METADATA = "datalink_metadata.yml"
RUNTIME_CONFIG = "runtime_config.yml"

_model_loaders = {
    '.joblib': lambda f: joblib.load(f),
    '.pkl': lambda f: pickle.load(f),
    '.pickle': lambda f: pickle.load(f)
}

type_dictionary = {
    'Bool': 'Bool',
    'Int': 'Integer',
    'Byte': 'Integer',
    'DInt': 'Integer',
    'Real': 'Double',
    'String': 'String',
    'Word': 'Integer',
    'LInt': 'Integer',
    'SInt': 'Integer',
    'USInt': 'Integer',
    'UInt': 'Integer',
    'UDInt': 'Integer',
    'ULInt': 'Integer',
    'LReal': 'Double',
    'DWord': 'Integer',
    'LWord': 'Integer',
    'Char': 'Integer',
    'BoolArray': 'BoolArray',
    'IntArray': 'IntegerArray',
    'ByteArray': 'IntegerArray',
    'DIntArray': 'IntegerArray',
    'RealArray': 'DoubleArray',
    'StringArray': 'StringArray',
    'WordArray': 'IntegerArray',
    'LIntArray': 'IntegerArray',
    'SIntArray': 'IntegerArray',
    'UIntArray': 'IntegerArray',
    'UDIntArray': 'IntegerArray',
    'Object': 'Object',
}
""" Dictionary where the keys correspond to S7 data types and values match AI Inference Server types."""


def find_dependencies(name: str, dependencies: dict):
    """
    Collects all dependencies of the Python module given with its `name` in the current Python environment.

    All inherited dependencies will be added to the `dependencies` dictionary with the installed version of the module.
    The method executes an OS command like `python -m pip show scikit-learn`.

    Args:
        name (str): Name of the Python module to be searched through for its dependencies.
        dependencies (dict): Dictionary to collect the dependencies with the module name as key, and the installed version as value.

    Returns:
        dict: The `dependencies` dictionary with the collected module names and versions.
    """

    cmd_line = [sys.executable, '-m', 'pip', 'show', name]
    result = subprocess.run(cmd_line, stdout=subprocess.PIPE, text=True)

    if not result.returncode == 0:
        print(f"Dependency {name} is not found and cannot be added.")
        return dependencies

    version = None
    for line in result.stdout.splitlines():

        version_matches = _version_matcher.match(line)
        if version_matches:
            version = version_matches.groups()[0].strip()

        transitive_matches = _transitive_matcher.match(line)
        if transitive_matches:
            transitives = transitive_matches.groups()[0].split(", ")
            for dependency in transitives:
                if dependency not in dependencies:
                    find_dependencies(dependency, dependencies)

    if name not in dependencies:
        spec = pep508.Spec(name, [], [('==', version)] if version else [], None)
        dependencies[name] = spec
        print("Found:", spec)
    return dependencies


def is_wheel_file(path: os.PathLike) -> bool:
    """
    Checks if the file on the given `path` is a wheel file or not.

    Args:
        path (path-like): The relative or absolute path of the wheel given file.
    Returns:
        bool: True if the zipfile contains a WHEEL text file, False otherwise.
    """
    if not zipfile.is_zipfile(path):
        return False

    _wheel = zipfile.ZipFile(path)
    return 'WHEEL' in [f.filename.split("/")[-1] for f in _wheel.filelist]


def python_version_validator(version: str):
    """
    Checks if Python version string is valid and describes supported version.

    Only Python major version 3 is supported. A patch version is optional and accepted but returns a warning.

    Accepted syntaxes are:

     - {major}.{minor}
     - {major}.{minor}.{patch}

    Args:
        version (str): Python version string

    Returns:
        (bool,str):  The first item is True if version string is valid, False otherwise.
                     If True, the second item is a warning message or None.
                     If False, the second item is an error message.
    """

    version = str(version)
    python_version_matcher = re.match(r'^3\.(0|[1-9][0-9]*)(\.(0|[1-9][0-9]*))?$', version)
    result = True
    message = None

    if python_version_matcher is None:
        result = False
        message = "The required Python version should be specified with major and minor version and major version must be '3', e.g. '3.8'"

    elif python_version_matcher.group(2) is not None:
        result = True
        message = """Required Python version was specified with patch version.
                Please note that the patch digit of the required Python version is often not taken into account by the Python ecosystem,
                so there is no guarantee it has the desired effect."""

    return result, message


class Component:
    """
    Base class for pipeline components, with name, description, and a list of inputs and outputs.

    A new component is created with the given name and an empty input and output list.

    Args:
        name (str): Name of the component
        desc (str): Optional description of the component
        inputs (dict): Dictionary of (name, type) pairs, which describe the input variables
        outputs (dict): Dictionary of (name, type) pairs, which describe the output variables
    """

    def __init__(self, name: str, desc: str = ""):
        """
        Creates a new component with the given name and an empty input and output list.

        Args:
            name (str): Name of the component.
            desc (str): Optional description of the component
        """

        self.name = name
        self.desc = desc
        self.inputs = {}
        self.outputs = {}
        self.metrics = {}

    def __repr__(self) -> str:
        text = f"[{self.__class__.__name__}] {self.name}\n"
        if self.desc != "":
            text += f"{self.desc}\n"
        if len(self.inputs) > 0:
            text += "\nComponent Inputs:\n"
            for name, input in self.inputs.items():
                text += f"> {name} ({input['type']}){': ' + input['desc'] if input.get('desc') is not None else ''}\n"
        if len(self.outputs) > 0:
            text += "\nComponent Outputs:\n"
            for name, output in self.outputs.items():
                text += f"< {name} ({output['type']}){': ' + output['desc'] if output.get('desc') is not None else ''}\n"
        if len(self.metrics) > 0:
            text += "\nMetrics:\n"
            for name, metric in self.metrics.items():
                text += f"< {name}{': ' + metric['desc'] if metric.get('desc') is not None else ''}\n"
        return text

    def add_input(self, name: str, _type: str, desc: str = None):
        """
        Adds a new input to the component with its type.
        The type must be contained in the `type_dictionary` as a value, but the most frequently used types are
        - String:
            Typically used for data received from Databus
        - Object:
            Object type variables are designed to receive from Vision Connect or transfer images between components
        - Numeric scalar types:
            Typically used for data received from S7 Connector

        The example payload below shows the format of image received from VCA Connector
        ```python
            payload = { "image":
                {
                    "resolutionWidth": image.width,
                    "resolutionHeight": image.height,
                    "mimeType": ["image/raw"],
                    "dataType": "uint8",
                    "channelsPerPixel": 3,
                    "image": _swap_bytes(image.tobytes())
                }
            }
        ```
        Between components the format is the same format as the format of Object as an output.
        ```python
            "processedImage": {
                "metadata": json.dumps( {
                                "resolutionWidth": image.width,
                                "resolutionHeight": image.height
                                }
                            ),
                "bytes": image.tobytes()
            }
        ```

        Args:
            name (str): Name of the new input.
            _type (str): Type of the new input.
            desc (str): Description of the input. (optional)
        """
        if self.inputs is None:
            self.inputs = {}
        if name in self.inputs:
            raise AssertionError(f"Input '{name}' already exists")
        if _type not in type_dictionary.values():
            raise AssertionError(f"Invalid input type: '{_type}'")
        self.inputs[name] = {
            "type": _type,
        }
        if desc is not None:
            self.inputs[name]['desc'] = desc

    def change_input(self, name: str, _type: str, desc: str = None):
        """
        Changes one of the inputs of the component.

        Args:
            name (str): Name of the input to be changed.
            _type (str): New type of the input.
            desc (str): Description of the input. (optional)
        """
        if name not in self.inputs:
            raise AssertionError(f"There is no input with name '{name}'")
        if _type not in type_dictionary.values():
            raise AssertionError(f"Invalid input type: '{_type}'")
        self.inputs[name]['type'] = _type
        if desc is not None:
            self.inputs[name]['desc'] = desc

    def delete_input(self, name: str):
        """
        Deletes an input from the component by name.
        Once the package has been created with the given component, it is recommended not to change the component directly.
        Instead, all necessary methods to change it are available through the package to avoid component inconsistencies.
        It is recommended to use `package.delete_input_wire(...)` with default parameter `with_input=True`.

        Args:
            name (str): Name of the input to be deleted.
        """
        if name not in self.inputs:
            raise AssertionError(f"Component '{self.name}' has no input '{name}'")
        self.inputs.pop(name)

    def add_output(self, name: str, _type: str, desc: str = None):
        """
        Adds a new output to the component.

        The type must be contained in the `type_dictionary` as a value, but the most frequently used types are
        - String:
            Typically used for data to be sent to Databus
        - Object:
            Typically used for images to be sent to ZMQ Connector
        - Numeric scalar types:
            Typically used for data sent to S7 Connector

        For outputs of type `Object` the entrypoint must return with a `dictionary` containing two fields, where one field has type `str` and the other field has type `bytes`.
        The example below shows the required format, assuming that 'image' is a PIL Image.
        ```python
            "processedImage": {
                "metadata": json.dumps( {
                                "resolutionWidth": image.width,
                                "resolutionHeight": image.height
                                }
                            ),
                "bytes": image.tobytes()
            }
        ```

        Args:
            name (str): Name of the new output.
            _type (str): Type of the new output.
            desc (str): Description of the output. (optional)
        """
        if self.outputs is None:
            self.outputs = {}
        if name in self.outputs:
            raise AssertionError(f"Output '{name}' already exists")
        if _type not in type_dictionary.values():
            raise AssertionError(f"Invalid output type: '{_type}'")
        self.outputs[name] = {
            "type": _type,
        }
        if desc is not None:
            self.outputs[name]['desc'] = desc

    def change_output(self, name: str, _type: str, desc: str = None):
        """
        Changes one of the outputs of the component.

        Args:
            name (str): Name of the output to be changed.
            _type (str): The new type of the output.
            desc (str): Description of the output. (optional)
        """
        if name not in self.outputs:
            raise AssertionError(f"There is no output with name '{name}'")
        if _type not in type_dictionary.values():
            raise AssertionError(f"Invalid output type: '{_type}'")
        self.outputs[name]['type'] = _type
        if desc is not None:
            self.inputs[name]['desc'] = desc

    def delete_output(self, name: str):
        """
        Deletes an output from the component by name.
        Once the package has been created with the given component, it is recommended not to change the component directly.
        Instead, all necessary methods to change it are available through the package to avoid component inconsistencies.
        Deleting an output which is represented in any wire will cause package inconsistency.

        Args:
            name (str): Name of the output to be deleted.
        """
        if name not in self.outputs:
            raise AssertionError(f"Component '{self.name}' has no output '{name}'")
        self.outputs.pop(name)

    def add_metric(self, name: str, desc: str = None):
        """
        Adds a component metric that will be automatically used as a pipeline output.

        Args:
            name (str): Name of the metric.
            desc (str): Description of the metric. (optional)
        """
        if "_" not in name:
            raise AssertionError("The metric name must contain at least one underscore")
        if self.metrics is None:
            self.metrics = {}
        if name in self.metrics:
            raise AssertionError(f"Metric '{name}' already exists")
        self.metrics[name] = {}
        if desc is not None:
            self.metrics[name]['desc'] = desc

    def delete_metric(self, name: str):
        """
        Remove a previously added metric.

        Args:
            name (str): Name of the metric to be deleted.
        """
        if name not in self.metrics:
            raise AssertionError(f"Component '{self.name}' has no metric '{name}'")
        self.metrics.pop(name)

    def _to_dict(self):
        return {
            'name': self.name,
            'description': self.desc
        }

    def validate(self):
        """
        Empty method, because only one child class implements this.
        """
        pass

    def save(self, destination, validate):
        """
        Empty method, because only one child class implements this.
        """
        pass


class PythonComponent(Component):
    """
    A pipeline component implemented using Python scripts and libraries.

    A `PythonComponent` wraps Python code resource files such as saved models into a structured folder, which can be added to a pipeline
    configuration package.

    For a comprehensive overview on how to wrap ML models into Python components, we recommend you refer to
    the AI SDK User Manual, especially the guideline for writing pipeline components. We also recommend you
    study the example Python components in the project templates for the AI SDK.

    A new `PythonComponent` is empty.

    Args:
        name (str): Component name. (default: inference)
        desc (str): Component description (optional)
        version (str): Component version. (default: 0.0.1)
        python_version (str): Python version on the target AI Inference Server.
            At the moment of writing, the current version supports Python 3.8.
    """

    def __init__(self, name="inference", version="0.0.1", python_version='3.8', desc: str = ""):
        """
        Creates a new, empty Python component.

        Args:
            name (str): Component name. (default: inference)
            desc (str): Component description (optional)
            version (str): Component version. (default: 0.0.1)
            python_version (str): Python version on the target AI Inference Server. At the moment of writing, AI Inference Server supports Python 3.8.
        """

        super().__init__(name=name, desc=desc)

        self.version = version
        self.entrypoint = None

        self.dependencies = {}

        python_version_ok, version_message = python_version_validator(python_version)
        if not python_version_ok:
            raise AssertionError(version_message)
        self.python_version = python_version

        self.resources = {}

        self.python_packages = None

        self._replicas = 1

    def __repr__(self) -> str:
        text = super().__repr__()
        if len(self.resources):
            text += "\nResources:\n"
            for path, base in self.resources.items():
                text += f"  {base}/{path.name}\n".replace('./', '')
        if self.entrypoint is not None:
            text += f"Entrypoint: {self.entrypoint}\n"
        return text

    @staticmethod
    def from_saved_model(base_dir, model_path, name="inference", version="0.0.1", python_version='3.8', desc: str = ""):
        """
        @Deprecated
        Creates a `PythonComponent` from a structured pickle or joblib file.

        The file should contain a Python dictionary containing the following:

        - `model`: A Python object representing the model, e.g., a scikit-learn pipeline object.
        - `input_columns`: Input column names as a list of strings, which the PythonComponent uses to create input variables for the component.
        - `output_name`: Output column names as a string, which the PythonComponent uses to create a single output variable for the component.

        Args:
            base_dir (str): The root folder of your code from which the resources are referred
            model_path (str): Relative path of the structured model file to the base_dir
            name (str): Name of the component
            desc (str): Component description (optional)
            version (str): Version information for the component
            python_version (str): Targeted Python version
        Returns:
            PythonComponent: If successful, returns with the created PythonComponent
        Exceptions:
            AssertionError: With the message of error occurred
        """
        _logger.warn("Method is deprecated. Please use standard constructor of PythonComponent instead.")
        component = PythonComponent(name, version, python_version, desc=desc)

        component._add_model(base_dir, model_path)

        return component

    def _add_model(self, base_dir: str or os.PathLike, model_path: str):
        """
        Internal method to add model to PythonComponent and automatically create the inputs and outputs of the component based on the defined information in the joblib (or pickle) file

        Args:
            base_dir (path-like): Root folder of your code where the resources are referred from.
            model_path (str): Relative path of the structured model file to the base_dir.
        """
        base_dir = Path(base_dir)
        model_file = base_dir / model_path
        extension = model_file.suffix
        if extension not in _model_loaders.keys():
            raise AssertionError(f"Not supported file extension. Only supported: {_model_loaders.keys()}")
        with open(model_file, 'rb') as f:
            try:
                model = _model_loaders[extension](f)
                if type(model) is not dict:
                    raise AttributeError("The `from_saved_model` method can only process models that are also a dictionary containing keys: 'input_columns', 'output_name' and 'model'.")

                self.add_output(model['output_name'], "Integer")

                for variable in model['input_columns']:
                    self.add_input(variable, "Double")
            except AttributeError as e:
                raise AttributeError(
                    f"Error occurred during deserialization of the saved model. Please make sure that function and class definitions required for the saved objects are importable in the runtime environment. Original error: {e}")
        self.add_resources(base_dir, model_path)

    def set_entrypoint(self, entrypoint: str):
        """
        Sets the entrypoint module for the component.

        The entrypoint is the Python code which is responsible for receiving the input data and producing a structured response with the output for the AI Inference Server.
        The script should consume a JSON string and produce another. See the short example below.

        The file will be copied into the root directory of the component on the AI Inference Server, so every file reference should be aligned.

        The example code below shows a basic structure of the entrypoint Python code.
        ```python
        import json
        import sys
        from pathlib import Path

        # by adding the parent folder of your modules to system path makes them available for relative import
        sys.path.insert(0, str(Path('./src').resolve()))
        from my_module import processor  # then the processor module can be imported

        def run(data: str):
            input_data = json.loads(data)  # incoming JSON string is loaded as a dictionary

            result = processor.process_data(input_data)  # the process_data can be called to process the incoming data

            # the code below creates the formatted output for the AI Inference Server
            if result is None:
                answer = {"ready": False, "output": None}
            else:
                answer = {"ready": True, "output": json.dumps(result)}

            return answer
        ```

        Args:
            entrypoint (str): Name of the new entrypoint script to be copied

    """

        if not any(key.name for key, value in self.resources.items() if key.name == entrypoint and value == '.'):
            raise AssertionError("Entrypoint must be added as resource to the root directory before setting up as entrypoint.")

        self.entrypoint = Path(entrypoint)

    def add_resources(self, base_dir: os.PathLike, resources: os.PathLike or list):
        """
        Adds files to a component.

        To make your file resources available on the AI Inference Server you need to add them to the package resources.
        These resources can be Python or config files, serialized ML models or reference data.
        They are then available on path {component_root}/{resources} in the runtime environment.
        When saving the package they will be copied from {base_dir}/{resources} into the package.
        Files in '__pycache__' folders or any other hidden folders (folder name starting with '.' character) will be excluded.

        Args:
            base_dir (path-like): Root folder of your code from which the resources are referred
            resources (os.PathLike or List): A single path or list of relative paths to resource files

        """

        base_dir = Path(base_dir).resolve().absolute()
        if not base_dir.is_dir():
            raise AssertionError(f"Parameter 'base_dir' must be a directory and available in path {base_dir}.")
        resources = resources if type(resources) is list else [resources]

        for resource in resources:
            self._add_resource(base_dir, resource)

    def _add_resource(self, base_dir: Path, resource: os.PathLike):
        if Path(resource).is_absolute() or '..' in resource:
            raise AssertionError("The resource path must be relative and cannot contain '/../' elements.")

        resource_path = base_dir / resource

        if resource_path.is_file():
            self._add_resource_file(base_dir, resource_path)
            return

        if resource_path.is_dir():
            for glob_path in resource_path.rglob("*"):
                if glob_path.is_file():
                    self._add_resource_file(base_dir, glob_path)
            return

        raise AssertionError(f"Specified resource is not a file or directory: '{resource}'")

    def _add_resource_file(self, base_dir: Path, resource_path: Path):
        for parent in resource_path.parents:
            if parent.name == '__pycache__' or str(parent.name).startswith('.'):
                return

        if resource_path in self.resources.keys():
            _logger.warning(f"Resource '{resource_path}' is already added to target directory '{self.resources[resource_path]}'")
            return

        self.resources[resource_path] = f"{resource_path.parent.relative_to(base_dir)}"

    def add_dependencies(self, packages: list):
        """
        Adds required dependencies for the Python code.

        The list must contain the name of the Python packages which are required for the AI Inference Server to execute the component.
        The method will search for the packages in the current Python environment and collect their transitive dependencies as well.
        When the version is also defined (in a tuple), the method will not search for the transitive dependencies.

        Args:
            packages (list): Can be a list of strings (name) or a list of tuples (name, version) of the required packages for component execution
        """

        for package in packages:
            if isinstance(package, tuple):
                spec = pep508.Spec(package[0], [], [('==', package[1])], None)
                self.dependencies[spec.name] = spec
                print("Added:", spec)
            elif not any(package.lower() == dep.lower() for dep in self.dependencies):
                find_dependencies(package, self.dependencies)

    def set_requirements(self, requirements_path: os.PathLike):
        """
        Reads the defined dependencies from the given `requirements.txt` file and creates a new dependency list.

        The file format must follow Python's requirements file format defined in PEP 508.

        Args:
            requirements_path (str): Path of the given `requirements.txt` file
        """
        if len(self.dependencies) > 0:
            _logger.warning("Previously added dependencies have been removed.")

        self.dependencies.clear()

        dependencies = {}
        invalid_lines = []
        with open(requirements_path, "r") as requirements_file:
            for line in requirements_file.readlines():
                line = line.strip()
                if line.startswith('#') or line == "":
                    continue
                try:
                    spec: pep508.Spec = pep508.parse_line(line)
                    dependencies[spec.name] = spec
                except Exception as e:
                    invalid_lines.append(line + "\n    " + e)

        if len(invalid_lines) > 0:
            raise AssertionError(f"Requirements file '{requirements_path}' contains invalid dependency specifications:\n" + '\n  '.join(invalid_lines))

        for name, spec in dependencies.items():
            self.dependencies[name] = spec
            print(f"Runtime dependency added: {spec}")

    def _add_wheel_dependency(self, wheel_name) -> None:
        """
        Adds the python dependency to the component dependencies list extracting its name and version from the name of the wheel file.

        Args:
            wheel_name (str):   Standard name of the wheel file with structure
                                '{distribution}-{version}(-{build tag})?-{python tag}-{abi tag}-{platform tag}.whl'
        """
        name, version, _ = wheel_name.split("-", 2)
        self.dependencies[name] = pep508.Spec(name, [], [('==', version)], None)
        find_dependencies(name, self.dependencies)

    def add_python_packages(self, path: str) -> None:
        """
        Adds Python package(s) to the `PythonPackages.zip` file of the component.

        The `path` parameter can refer either a `zip` or a `whl` file.
        When the path refers to a zip file, the file must contain only wheel files, and all the wheel files are added to `PythonPackages.zip`
        The dependency files of the component will be extended with the specifications, so that they not only get passed to but also get installed on the AI Inference Server.
        The method uses the `tempfile.tempdir` folder, so make sure that the folder is writeable.

        The wheel files must fulfill the requirements of the targeted device environment
        (e.g., the Python version used must match the Python version of the target AI Inference Server,
        the platform should be one of the supported ones or 'any').

        Args:
            path (str): Path of the wheel or the zip file

        Examples:
            `component.add_python_packages('../resources/my_package-0.0.1-py3-none-any.wheel')`
                adds the wheel file to `PythonPackages.zip` and adds dictionary item `component.dependencies['my_package'] = '0.0.1'`

            `component.add_python_packages('../resources/inference-wheels.zip')`
                adds all the wheel files in the zip to `PythonPackages.zip` and `component.dependencies`
        """
        path = Path(path)
        if not path.is_file():
            raise AssertionError(f"The file must be available on path {path.resolve()}")

        if self.python_packages is None:
            tempdir = tempfile.mkdtemp()
            self.python_packages = Path(tempdir) / f"PythonPackages_{self.name}-{self.version}.zip"
            write_mode = "w"
        else:
            tempdir = self.python_packages.parent
            write_mode = "a"

        if is_wheel_file(path):
            with zipfile.ZipFile(self.python_packages, write_mode) as zip_file:
                zip_file.write(path, path.name)
                self._add_wheel_dependency(path.name)
        elif zipfile.is_zipfile(path):
            if len(list(zipfile.ZipFile(path).filelist)) < 1:
                raise AssertionError("The zip file cannot be empty")

            with zipfile.ZipFile(path) as zip_file:
                for f in zip_file.filelist:
                    extract_path = zip_file.extract(f, tempdir)
                    if not is_wheel_file(Path(extract_path)):
                        raise AssertionError("The zip file must contain only wheel files (zip files with a WHEEL entry).")
                    self._add_wheel_dependency(f.filename)
                    with zipfile.ZipFile(self.python_packages, write_mode) as packages_zip:
                        packages_zip.write(extract_path, f.filename)
                    os.remove(extract_path)
                    write_mode = "a"
        else:
            raise AssertionError("The file is neither a wheel nor a zip file with wheels.")

    def set_parallel_steps(self, replicas):
        """
        Sets the number of parallel executors.

        This method configures how many instances of the component can be
        executed at the same time.
        The component must be suitable for parallel execution. The inputs arriving
        to the component will be processed by different instances in parallel,
        and these instances do not share their state (e.g. variables). Every
        instance is initialized separately and receives only a fraction of the inputs.
        AI Inference Server supports at most 8 parallel instances.```

        Args:
            replicas (int): Number of parallel executors. Default is 1.

        Raises:
            ValueError: if the given argument is not a positive integer.
        """
        if (not isinstance(replicas, int)) or replicas < 1:
            raise ValueError("Replica count must be a positive integer.")
        if 8 < replicas:
            _logger.warning("The current maximum of parallel executors is 8.")
        self._replicas = replicas

    def _to_dict(self):
        inputs = []
        inputs += [{
            'name': name,
            'type': self.inputs[name]['type'],
        } for name in self.inputs]

        outputs = []
        outputs += [{
            'name': name,
            'type': self.outputs[name]['type'],
        } for name in self.outputs]
        outputs += [{
            'name': name,
            'type': 'String',
        } for name in self.metrics.keys()]

        return {
            'name': self.name,
            'description': self.desc,
            'version': self.version,
            'entrypoint': f"./{self.entrypoint.name}",
            'hwType': 'CPU',
            'runtime': {
                'type': 'python',
                'version': self.python_version
            },
            'replicas': self._replicas,
            'inputType': inputs,
            'outputType': outputs
        }

    def validate(self):
        """
        Validates that the component is ready to be serialized and packaged as part of a pipeline.
        """
        if self.entrypoint is None:
            raise AssertionError("Entrypoint must be defined")
        if not any(key.name for key, value in self.resources.items() if key.name == self.entrypoint.name and value == '.'):
            raise AssertionError("Entrypoint must be added as resource to the root directory before setting up as entrypoint.")

        _logger.info(f"Component '{self.name}' is valid and ready to use.")

    def save(self, destination, validate=True):
        """
        Saves the component to a folder structure, so it can be used as part of a pipeline configuration package.
        Validation can be skipped by setting parameter `validate` to False.
        This is useful when the component is already validated and only intended to be saved.

        The component folder contains the following:

        - `requirements.txt` with a list of Python dependencies
        - Entry point script defined by the `entrypoint` attribute of the component
        - Extra files as added to the specified folders
        - `PythonPackages.zip` with the wheel binaries for the environment to be installed

        Args:
            destination (path-like): Target directory to which the component will be saved.
            validate (bool): With value True, triggers component validation. Defaults to True.
        """
        if validate:
            self.validate()

        folder_path = Path(destination) / self.name
        folder_path.mkdir(parents=True, exist_ok=True)

        for file_path in self.resources:
            dir_path = folder_path / self.resources[file_path]
            os.makedirs(dir_path, exist_ok=True)
            shutil.copy(file_path, dir_path / file_path.name)

        if self.python_packages is not None:
            shutil.copy(self.python_packages, os.path.join(folder_path, PYTHON_PACKAGES_ZIP))
            os.remove(self.python_packages)
            os.rmdir(self.python_packages.parent)

        with open(folder_path / "requirements.txt", "w") as f:
            f.write("# Runtime dependencies\n")
            for spec in self.dependencies.values():
                f.write(str(spec) + "\n")


class Pipeline:
    """
    `Pipeline` represents a pipeline configuration package with `Components` and wires to provide a data flow on the AI Inference Server.
    The `Components` have inputs and outputs to transfer data to each other and the wires describe this data flow between them.
    The package also contains configuration files required to deploy a pipeline on an Industrial Edge device.

    A newly initialized `Pipeline` does not contain any `Component` or wire, only its name and version will be set.
    The name and version together will define the name of the zip file when the package is saved.

    Args:
        name (str): Name of the package
        version (str): Version of the package
    """
    _wire_hash_string = "{}.{} -> {}.{}"

    def __init__(self, name: str, version: str, desc: str = ""):
        """
        A newly initialized `Pipeline` will contain no `Component` or wire, just its name and version will be set.
        The name and version will define together the name of the zip file when the package is saved.

        Args:
            name (str): Name of the package
            desc (str): Package description (optional)
            version (str): Version of the package
        """

        self.name = name
        self.desc = desc
        self.version = version

        self.author = 'AI SDK'

        self.components = {}
        self.wiring = {}
        self.parameters = {}

        self.periodicity = None
        self.timeshift_reference = []

        self.inputs = []
        self.outputs = []
        self.log_level = logging.INFO

    def _set_log_level(self, log_level: int):
        self.log_level = log_level
        _logger.setLevel(self.log_level)

    @staticmethod
    def from_components(components: list, name: str, version: str, desc: str = ""):
        """
        Creates a pipeline configuration from the given components.
        The components are linked in a linear sequence with inputs and outputs auto-wired based on the name of the inputs and outputs of the components.
        The inputs of the first component will be wired as the pipeline inputs and the outputs of the last component will be wired as the pipeline outputs.
        The components must have unique names. Two or more versions of the same component can not be packaged simultaneously without renaming them.

        Args:
            components (list): List of PythonComponents
            name (str): Name of the pipeline
            version (str): Version information of the pipeline
        Returns:
            Pipeline: Pipeline object with the auto-wired components
        """
        pipeline = Pipeline(name, version, desc=desc)

        first_component = components[0]
        pipeline.add_component(first_component)
        pipeline.inputs = [(first_component.name, component_input) for component_input in first_component.inputs]
        pipeline.outputs = [(first_component.name, output) for output in first_component.outputs]

        for component in components[1:]:
            pipeline.add_component(component)
            for (wire_component, wire_name) in pipeline.outputs:
                try:
                    pipeline.add_wiring(wire_component, wire_name, component.name, wire_name)
                except Exception as e:
                    _logger.warning(f"Output variable {wire_component}.{wire_name} couldn't be auto-wired.\nCause: {e}")

            unwired_variables = [f'{component.name}.{x}' for x in component.inputs if not any(s.endswith(f'{component.name}.{x}') for s in pipeline.wiring)]
            if len(unwired_variables) > 0:
                for variable in unwired_variables:
                    _logger.warning(f"Input variable {variable} couldn't be auto-wired.\n")
            pipeline.outputs = [(component.name, output) for output in component.outputs]

        return pipeline

    def __repr__(self) -> str:
        """
        Textual representation of the configured package.
        The method shows the `Components` with their inputs, outputs and parameters as well as the wiring between these `Components`.

        Returns:
            [str]: Textual representation of the package
        """

        text = f"[{self.__class__.__name__}] {self.name} ({self.version})\n"
        if self.desc != "":
            text += f"{self.desc}\n"

        if len(self.parameters) > 0:
            text += "\nPipeline Parameters:\n"
            for name, parameter in self.parameters.items():
                text += f"- {name} ({parameter['type']}, default: '{parameter['defaultValue']}'){(': ' + parameter['desc']) if parameter.get('desc') is not None else ''}\n"

        if len(self.inputs) > 0:
            text += "\nPipeline Inputs:\n"
            for component, name in self.inputs:
                input = self.components[component].inputs[name]
                text += f"> {name} ({input['type']}){': ' + input['desc'] if input.get('desc') is not None else ''}\n"

        if len(self.outputs) > 0:
            text += "\nPipeline Outputs:\n"
            for component, name in self.outputs:
                output = self.components[component].outputs[name]
                text += f"< {name} ({output['type']}){': ' + output['desc'] if output.get('desc') is not None else ''}\n"

        metrics = [(name, metric, component_name) for component_name, component in self.components.items() for name, metric in component.metrics.items()]
        if len(metrics) > 0:
            text += "\nMetrics:\n"
            for name, metric, _ in metrics:
                text += f"< {name}{': ' + metric['desc'] if metric.get('desc') is not None else ''}\n"

        if len(self.wiring) > 0:
            text += "\nI/O Wiring:\n"
            for component, name in self.inputs:
                text += f"  {name} -> {component}.{name}\n"
            for wire_hash in self.wiring:
                text += f"  {wire_hash}\n"
            for component, name in self.outputs:
                text += f"  {component}.{name} -> {name}\n"
            for name, metric, component_name in metrics:
                text += f"  {component_name}.{name} -> {name}\n"

        if self.periodicity is not None:
            text += "\nTimeshifting:\n"
            text += f"  Periodicity: {self.periodicity} ms\n"
            if len(self.timeshift_reference) > 0:
                text += "  References:\n"
                for ref in self.timeshift_reference:
                    text += f"  - {ref}\n"

        for component in self.components.values():
            text += "\n" + component.__repr__()

        return text

    def add_input(self, component, variable):
        """
        Defines an input variable on the given component as a pipeline input.

        Args:
            component (str): Name of the component
            variable (str): Name of the input variable
        """
        try:
            _ = self.components[component].inputs[variable]
        except KeyError:
            raise AssertionError("The component with input variable must exist in the pipeline.")

        if self.inputs is None:
            self.inputs = []

        if (component, variable) in self.inputs:
            raise AssertionError("The pipeline input already exists.")

        self.inputs.append((component, variable))

    def delete_input(self, component: str, variable: str):
        """
        Deletes a pipeline input.

        Args:
            component (str): Name of the component
            variable (str): Name of the input variable

        """
        if (component, variable) not in self.inputs:
            raise AssertionError("The pipeline input does not exist.")

        self.inputs.remove((component, variable))

    def add_output(self, component, variable):
        """
        Defines an output variable on the given component as a pipeline output.

        Args:
            component (str): Name of the component
            variable (str): Name of the output variable

        """
        try:
            _ = self.components[component].outputs[variable]
        except KeyError:
            raise AssertionError("The component with output variable must exist in the pipeline.")

        if self.outputs is None:
            self.outputs = []

        if (component, variable) in self.outputs:
            raise AssertionError("The pipeline output already exists.")

        self.outputs.append((component, variable))

    def delete_output(self, component: str, variable: str):
        """
        Deletes a pipeline output.

        Args:
            component (str): Name of the component
            variable (str): Name of the input variable

        """
        if (component, variable) not in self.outputs:
            raise AssertionError("The pipeline output does not exist.")

        self.outputs.remove((component, variable))

    def add_component(self, component: Component):
        """
        Adds a `Component` to the pipeline configuration without any connection.
        The `Component` can be marked as an input or output component of the pipeline.
        When these parameters are True, the `Component` is responsible for input or output data of the pipeline.
        The component must have a unique name. Two or more versions of the same component can not be added to the same pipeline with the same component name.

        Args:
            component (Component): `Component` to be added
        """

        if component.name in self.components:
            raise AssertionError(f"Component with name {component.name} already exists. Please rename the component.")
        if type(component) != PythonComponent:
            raise AssertionError("Only PythonComponent is supported.")
        self.components[component.name] = component

    def add_wiring(self, from_component: str, from_output: str, to_component: str, to_input: str):
        """
        Creates a one-to-one connection between the input and output of two components.
        The method checks if the connection is allowed with the following requirements:

        - The components exist with the given inputs/outputs
        - The given inputs and outputs are not connected to any wire
        - The types of the connected input and output are compatible

        Args:
            from_component (str): Name of the component which provides data to the `to_component`
            from_output (str): Name of the output variable of the `from_component`
            to_component (str): Name of the component which consumes data from the `from_component`
            to_input (str): Name of the input variable of the `to_component`
        """
        if from_component not in self.components:
            raise AssertionError(f"No component named '{from_component}'")
        if to_component not in self.components:
            raise AssertionError(f"No component named '{to_component}'")
        if from_output not in self.components[from_component].outputs:
            raise AssertionError(f"Component '{from_component}' has no output named '{from_output}'")
        if to_input not in self.components[to_component].inputs:
            raise AssertionError(f"Component '{to_component}' has no input named '{to_input}'")
        if self.get_wire_for_input(to_component, to_input) is not None:
            raise AssertionError(f"Input '{to_input}' of component '{to_component}' is already wired")

        _output_type = self.components[from_component].outputs[from_output]["type"]
        _input_type = self.components[to_component].inputs[to_input]["type"]
        if _output_type != _input_type:
            raise AssertionError("Output and input types do not match")

        wire_hash = self._wire_hash_string.format(from_component, from_output, to_component, to_input)
        self.wiring[wire_hash] = {
            "fromComponent": from_component,
            "fromOutput": from_output,
            "toComponent": to_component,
            "toInput": to_input,
        }

    def get_wire_for_output(self, component_name: str, output_name: str):
        """
        Searches for the wire which connects a component with `component_name` as data provider through its output with name output_name.

        Args:
            component_name (str): Name of the data provider component.
            output_name (str): Name of the output variable of `component_name`.

        Returns:
            [dict]: Wire which contains the data provider and receiver with their names and the names of their variables.
        """
        wires = [x for x in self.wiring.values() if x["fromComponent"] == component_name and x["fromOutput"] == output_name]
        return wires[0] if wires else None

    def get_wire_for_input(self, component_name: str, input_name: str):
        """
        Searches for the wire which connects a component with `component_name` as data consumer through its input with name `input_name`.

        Args:
            component_name (str): Name of the data consumer component.
            input_name (str): Name of the input variable of `component_name`.

        Returns:
            dict: Wire which contains the data provider and receiver with their names and the names of their variables.
        """
        wires = [x for x in self.wiring.values() if x["toComponent"] == component_name and x["toInput"] == input_name]
        return wires[0] if wires else None

    def delete_input_wire(self, component: str, variable: str, with_input: bool = True):
        """
        Deletes an existing connection between two components.
        The connection must be given with the name of the consumer component and its input variable.
        If an inter signal alignment reference variable is affected it cannot be deleted.
        By default, the input variable will be also deleted.

        Args:
            component (str): Name of the component which has the input given the name variable
            variable (str): Name of the input variable on the component which connected by the wire
            with_input (bool, optional): If set, the input variable will be also deleted from the component. Defaults to True.

        Raises:
            AssertionError: When the variable acts as inter signal alignment reference, it cannot be deleted, and an `AssertionError` will be raised.
        """
        wire = self.get_wire_for_input(component, variable)
        if wire is None:
            raise AssertionError(f"There is no wiring for input '{variable}' of component '{component}'")
        if variable in self.timeshift_reference:
            raise AssertionError("Inter signal alignment reference variables can not be deleted.")
        wire_hash = self._wire_hash_string.format(wire['fromComponent'], wire['fromOutput'], wire['toComponent'], wire['toInput'])
        self.wiring.pop(wire_hash)

        if with_input:
            self.components[component].delete_input(variable)

    def add_dependencies(self, packages: list):
        """
        Collects the given Python packages with their versions from the executing Python environment and add them to all components of type `PythonComponent`.
        This step is necessary in order to execute the pipeline configuration on the Edge side.
        The method can be called multiple times but each time the previously-collected dependencies are cleared.
        The reason for this is to ensure a consistent dependency list for the `requirements.txt` file when the package is saved.

        Args:
            packages (list): List of the necessary python packages to execute the script defined by self.entrypoint
        """
        python_components = [self.components[name] for name in self.components if type(self.components[name]) == PythonComponent]
        for component in python_components:
            component.add_dependencies(packages)

    def set_timeshifting_periodicity(self, periodicity: int):
        """
        Enables inter-signal alignment with the given sampling period.

        With inter-signal alignment enabled, the AI Inference Server collects data for different input variables before it triggers the model.
        By default, `startingPoint` property is set to `First timestamp`, which means that inter-signal alignment is started at the
        first incoming value for any input variable.

        This property can be changed to `Signal reference` by adding inter-signal alignment reference variables
        via the `add_timeshifting_reference(..)` method. In this case, inter-signal alignment is started when the first value arrives
        for the defined input variables.

        Args:
            periodicity (int): Periodicity time in milliseconds for the AI Inference Server to perform inter-signal alignment. Valid range is [10, 2^31).
        """

        periodicity = int(periodicity)
        if periodicity not in range(10, int(math.pow(2, 31))):
            raise AssertionError("Inter signal alignment periodicity must be an integer and in range [10, 2^31)")

        self.periodicity = periodicity
        _logger.info(f"Inter signal alignment periodicity has been set to {self.periodicity}.")

    def add_timeshifting_reference(self, reference: str):
        """
        Enables signal alignment mode `Signal reference` by declaring input variables as reference variables.

        Args:
            reference (str): Variable name to be added to `self.timeshift_reference` list.
        """
        if reference not in [name for _, name in self.inputs]:
            raise AssertionError(f"There is no input variable defined with name '{reference}'")
        if reference in self.timeshift_reference:
            _logger.warning(f"Reference variable with name '{reference}' has been already added.")
            return
        self.timeshift_reference.append(reference)

    def remove_timeshifting_reference(self, reference: str):
        """
        Removes previously-defined inter-signal alignment reference variables.
        If no reference variables remain, the `startingPoint` will be `First timestamp`.

        Args:
            reference (str): Variable name to be removed from `self.timeshift_reference` list.
        """
        if reference not in self.timeshift_reference:
            raise AssertionError(f"Reference variable with name {'reference'} does not exist.")
        self.timeshift_reference.remove(reference)

    def get_pipeline_config(self):
        """
        Saves the information on the composed pipeline configuration package into a YAML file.

        This YAML file describes the components and the data flow between them for the AI Inference Server.
        The file is created in the `destination` folder with name `pipeline_config.yml`

        Args:
            destination (path-like): Path of the `destination` directory.
        """
        pipeline_inputs = []
        pipeline_inputs += [{
            'name': name,
            'type': self.components[component_name].inputs[name]['type']
        } for component_name, name in self.inputs]

        pipeline_outputs = []
        pipeline_outputs += [{
            'name': name,
            'type': self.components[component_name].outputs[name]['type'],
        } for component_name, name in self.outputs]
        pipeline_outputs += [{
            'name': name,
            'type': 'String',
            'topic': f"/siemens/edge/aiinference/{self.name}/{self.version}/metrics/{component_name}/{name}",
        } for component_name, component in self.components.items() for name in component.metrics.keys()]

        pipeline_dag = [{
            'source': f"{wire['fromComponent']}.{wire['fromOutput']}",
            'target': f"{wire['toComponent']}.{wire['toInput']}",
        } for wire in self.wiring.values()]
        pipeline_dag += [{
            'source': f'Databus.{name}',
            'target': f'{component_name}.{name}',
        } for component_name, name in self.inputs]
        pipeline_dag += [{
            'source': f'{component_name}.{name}',
            'target': f'Databus.{name}',
        } for component_name, name in self.outputs]
        pipeline_dag += [{
            'source': f'{component_name}.{name}',
            'target': f'Databus.{name}',
        } for component_name, component in self.components.items() for name in component.metrics.keys()]

        config_yml_content = {
            'fileFormatVersion': '1.2.0',
            'dataFlowPipelineInfo': {
                'author': self.author,
                'createdOn': datetime.now(),
                'dataFlowPipelineVersion': self.version,
                'description': self.desc if self.desc else 'Created by AI SDK',
                'projectName': self.name,
            },
            'dataFlowPipeline': {
                'components': [component._to_dict() for component in self.components.values()],
                'pipelineDag': pipeline_dag,
                'pipelineInputs': pipeline_inputs,
                'pipelineOutputs': pipeline_outputs,
            },
            'packageType': 'full'
        }
        if len(self.parameters.items()) != 0:
            config_yml_content["dataFlowPipeline"]["pipelineParameters"] = []
            for name, parameter in self.parameters.items():
                if parameter["topicBased"]:
                    config_yml_content["dataFlowPipeline"]["pipelineParameters"].append({
                        'name': name, 'type': parameter['type'],
                        'defaultValue': parameter['defaultValue'],
                        'topicBased': parameter['topicBased'], 'valueTopic': parameter['valueTopic']
                    })
                else:
                    config_yml_content["dataFlowPipeline"]["pipelineParameters"].append({
                        'name': name, 'type': parameter['type'],
                        'defaultValue': parameter['defaultValue']
                    })

        return config_yml_content

    def save_pipeline_config(self, destination):
        """
        Saves the information about the composed pipeline configuration package into a YAML file.

        This YAML file describes the components and the data flow between them for AI Inference Server.
        The file will be created in the `destination` folder with name `pipeline_config.yml`

        Args:
            destination (path-like): Path of the `destination` directory.
        """

        with open(Path(destination) / PIPELINE_CONFIG, "w") as f:
            yaml.dump(self.get_pipeline_config(), f)

    def get_datalink_metadata(self):
        """
        The method generates metadata information based on available information.

        Returns:
            dict: Dictionary with the necessary information for the AI Inference Server.
        """

        timeshifting = {
            "id": None,
            "enabled": False,
            "periodicity": self.periodicity,
            "startingPoint": None,
        }

        if self.periodicity is not None:
            timeshifting["enabled"] = True
            timeshifting["startingPoint"] = 'First timestamp'

        if len(self.timeshift_reference) > 0:
            timeshifting["startingPoint"] = 'Signal reference'

        exported_metadata = {
            "fileFormatVersion": "1.0.0",
            "id": None,
            "version": None,
            "createdOn": datetime.now(),
            "updatedOn": datetime.now(),
            "timeShifting": timeshifting,
            "inputs": [
                {
                    'name': _name,
                    'mapping': None,
                    'timeShiftingReference': _name in self.timeshift_reference,
                    'type': self.components[_component].inputs[_name]['type']
                } for _component, _name in self.inputs
            ]
        }
        return exported_metadata

    def save_datalink_metadata(self, destination):
        """
        Saves metadata for pipeline input variables.
        This method saves metadata for the AI Inference Server into a YAML file.
        This metadata determines how the AI Inference Server feeds input to the pipeline, especially inter-signal alignment.
        The file is created in the `destination` folder with the name `datalink_metadata.yml`

        Args:
            destination (path-like): Path of the destination directory.
        """
        with open(Path(destination) / DATALINK_METADATA, "w") as f:
            yaml.dump(self.get_datalink_metadata(), f)

    def save_readme_html(self, destination):
        """
        Saves a `README.html` in the `destination` folder that describes the pipeline.

        Args:
            destination (path-like): Path of the destination folder.
        """
        pipelinePage = PipelinePage(self)
        readme_html_path = Path(destination) / _README_HTML
        readme_html_path.write_text(pipelinePage.__str__())

    def validate(self, destination="."):
        """
        Validates whether the package configuration is compatible with the expected runtime environment.

        The method checks:

        - If the package has at least one component
        - If all wires create connections between existing components and their variables
        - If metadata is defined and valid.
        - If a package with the same name already exists in the `destination` folder. In this case a warning message appears and the `save(..)` method overwrites the existing package.

        Args:
            destination (str, optional): Path of the expected destination folder. Defaults to ".".
        """
        if len(self.components) < 1:
            raise AssertionError("The package must have at least one component.")

        for wire_hash in self.wiring.copy():
            wire = self.wiring[wire_hash]
            self._check_wiring(wire, wire_hash)

        self._check_timeshifting()

        package_path = Path(destination) / f"{self.name}_{self.version}".replace(" ", "-")
        if package_path.is_dir():
            _logger.warning(f"Target folder ({package_path}) already exists! Unless changing the package name the package could be invalid and your files will be overwritten!")

        for component in self.components:
            self.components[component].validate()

        _logger.info(f"Package '{self.name}' is valid and ready to save.")

    def _check_timeshifting(self):
        if len(self.timeshift_reference) > 0 and self.periodicity is None:
            raise AssertionError("When using inter signal alignment reference variables, the periodicity must be set.")

    def _check_wiring(self, wire, wire_hash):
        error_messages = []
        if wire['fromComponent'] not in self.components:
            error_messages.append(f"From component {wire['fromComponent']} does not exist")
        if wire['toComponent'] not in self.components:
            error_messages.append(f"To component {wire['toComponent']} does not exist")
        if wire['fromOutput'] not in self.components[wire['fromComponent']].outputs:
            error_messages.append(f"Output variable {wire['fromOutput']} does not exist on component {wire['fromComponent']}")
        if wire['toInput'] not in self.components[wire['toComponent']].inputs:
            error_messages.append(f"Input variable {wire['toInput']} does not exist on component {wire['toComponent']}")
        if len(error_messages) == 0:
            from_type_ = self.components[wire['fromComponent']].outputs[wire['fromOutput']]['type']
            to_type_ = self.components[wire['toComponent']].inputs[wire['toInput']]['type']
            if from_type_ != to_type_:
                error_messages.append(f"The types of input and output variables does not match for wiring {wire_hash}.")
        if len(error_messages) > 0:
            self.wiring.pop(wire_hash)
            error_messages.append("The wire has been deleted, please check the variables and re-create the connection.")
            raise AssertionError(error_messages.__str__())

    def save(self, destination=".") -> Path:
        """
        Saves the assembled package in a zip format.
        The name of the file is defined as `{package_name}_{package_version}.zip`.
        If a file with such a name already exists in the `destination` folder, it gets overwritten and a warning message appears.

        The package is also available as a subfolder on the destination path with the name `{package_name}_{package_version}`.
        If the assembled content does not meet the expected one, this content can be changed and simply packed into a zip file.

        The package contains files and folders in the following structure:

        - Package folder with name `{package_name}_{package_version}`
          - `datalink-metadata.yml`
          - `pipeline-config.yml`
          - Component folder with name `{component_name}`

            When the component is a `PythonComponent`, this folder contains:

            - `requirements.txt`
            - Entrypoint script defined by the entrypoint of the component
            - Extra files as added to the specified folders
            - Source folder with name `src` with necessary python scripts

        Args:
            destination (str, optional): Target directory for saving the package. Defaults to ".".
        """
        self.validate(destination)

        file_name = f"{self.name}_{self.version}".replace(" ", "-")
        destination = Path(destination) / file_name
        destination.mkdir(parents=True, exist_ok=True)

        for component in self.components:
            self.components[component].save(destination, False)

        self.save_datalink_metadata(destination)
        self.save_pipeline_config(destination)
        self.save_readme_html(destination)

        zip_destination = shutil.make_archive(
            base_name=str(destination.parent / file_name), format='zip',
            root_dir=destination.parent, base_dir=file_name,
            verbose=True, logger=_logger)

        return Path(zip_destination)

    def add_parameter(self, name, default_value, type_name: str = "String", topic_based: bool = False, desc: str = None):
        """
        Adds a parameter to the pipeline configuration, which alters the behavior of the pipeline.
        The parameter's default value and its properties are saved in the pipeline configuration
        and the value of the parameter can later be changed on AI Inference Server.

        Args:
            name (str): Name of the parameter
            desc (str): Description of the parameter (optional)
            type_name (str, optional): Data type of the parameter. Defaults to "String".
            default_value (str): Default value of the parameter
            topic_based (bool, optional): If true, the parameter can be updated from a message queue.

        Raises:

            ValueError:
                When:
                - the default value of the parameter is not of the specified data type (`type_name`) or
                - the specified data type itself is not an allowed data type (not a part of `parameter_types` dict) or
                - the specified data type is not given in the right format or
                - the type of the given `topic_based` parameter is not `bool`.
        """
        parameter_types = {
            "String": 'str',
            "Integer": 'int',
            "Double": 'float',
            "Boolean": 'bool'
        }

        default_value_type = type(default_value).__name__

        if type_name not in parameter_types.keys():
            raise ValueError(f"The given value type is not supported. Please use one of these: {parameter_types.keys()}")

        if default_value_type != parameter_types[type_name]:
            raise ValueError(f"The given value type does not match the type of '{type_name}'. Please use the correct one from these: {list(parameter_types.keys())}")

        if not isinstance(topic_based, bool):
            raise ValueError("Type of the given `topic_based` parameter is not `bool`.")

        self.parameters[name] = {
            "name": name,
            "type": type_name,
            "defaultValue": default_value,
            "topicBased": topic_based,
            "valueTopic": None
        }
        if desc is not None:
            self.parameters[name]["desc"] = desc


_PLATFORMS = [
    "any",
    "manylinux1_x86_64",
    "manylinux2010_x86_64",
    "manylinux2014_x86_64",
    "linux_x86_64"
]


def convert_package(zip_path: str or os.PathLike) -> Path:
    """
    Create an Edge Configuration Package from a given Pipeline Configuration Package.

    If the input zip file is `{path}/{name}_{version}.zip`, the output file will be created as `{path}/{name}-edge_{version}.zip`.
    Please make sure that the given zip file comes from a trusted source!

    If a file with such a name already exists, it is overwritten.

    First, this method verifies that the requirements identified by name and version are either included
    in `PythonPackages.zip` or available on pypi.org for the target platform.

    Currently, the supported edge devices run Linux on 64-bit x86 architecture, so the accepted Python libraries are restricted to the platform independent ones and packages built for 'x86_64' platforms.
    AI Inference Server​ also provides a Python 3.8 runtime environment, so the supported Python libraries are restricted to Python 3.8 compatible packages.

    If for the target platform the required dependency is not available on pypi.org
    and not present in `PythonPackages.zip`,  it will log the problem at ERROR level.
    Then it downloads all dependencies (either direct or transitive), and creates a new zip
    file, which is validated against the AI Inference Server's schema.
    This functionality requires pip with version of 21.3.1 or greater.

    This method can be used from the command line too.
    Example usage:
    ```
    python -m simaticai convert_package <path_to_pipeline_configuration_package.zip>
    ```

    Args:
        zip_path (path-like): path to the pipeline configuration package zip file.

    Returns:
        os.PathLike: The path of the created zip file.

    Exceptions:
        PipelineValidationError: If the validation fails. See the logger output for details.
    """
    zip_path = Path(zip_path)
    if zip_path.stem.find('_') < 0:
        raise AssertionError("The input zip file name must contain an underscore character.")
    with tempfiles.OpenZipInTemp(zip_path) as zip_dir:
        top_level_items = list(zip_dir.iterdir())
        if len(top_level_items) != 1:
            raise AssertionError("The Pipeline Configuration Package must contain a single top level directory.")
        package_dir = zip_dir / top_level_items[0]
        runtime_dir = zip_dir / "edge_config_package"
        config = yaml_helper.read_yaml(package_dir / PIPELINE_CONFIG)
        _validate_with_schema("input pipeline_config.yml", config, "pipeline.schema.json")
        runtime_config = _generate_runtime_config(config)
        for component in config['dataFlowPipeline']['components']:
            source_dir = package_dir / component["name"]

            python_version = component['runtime']['version']
            python_version_ok, version_message = python_version_validator(python_version)
            if not python_version_ok:
                raise AssertionError(version_message)
            if version_message is not None:
                _logger.warning(version_message)

            _package_component_dependencies(source_dir, python_version)
            _package_component(source_dir, runtime_dir / 'components' / f"{component['name']}_{component['version']}")
            runtime_config["runtimeConfiguration"]["components"].append({
                "name": component["name"],
                "device": "IED1",
                "targetRuntime": "Python",
            })
        shutil.copy(str(package_dir / PIPELINE_CONFIG), str(runtime_dir / PIPELINE_CONFIG))
        datalink_metadata_yaml = package_dir / DATALINK_METADATA
        if datalink_metadata_yaml.is_file():
            shutil.copy(str(datalink_metadata_yaml), runtime_dir / DATALINK_METADATA)

        _validate_with_schema("generated runtime_config.yml", runtime_config, "runtime.schema.json")
        with open(runtime_dir / "runtime_config.yml", "w", encoding="utf8") as file:
            yaml.dump(runtime_config, file)

        readme_html = package_dir / _README_HTML
        if readme_html.exists():
            (runtime_dir / _README_HTML).write_text(readme_html.read_text())

        return Path(shutil.make_archive(
            # One Pythonic Way to replace the last occurrence of "_" with "-edge".
            base_name=str(PurePath(zip_path).parent / "-edge_".join(zip_path.stem.rsplit("_", 1))),
            format='zip',
            root_dir=runtime_dir,
            verbose=True,
            logger=_logger))


def _package_component(source_dir, target_name):
    return shutil.make_archive(
        base_name=target_name,
        format='zip',
        root_dir=source_dir,
        verbose=True,
        logger=_logger)


def _package_component_dependencies(component_dir: Path, python_version: str):
    python_packages_folder = component_dir / 'packages'
    requirements_file_path = component_dir / 'requirements.txt'
    packages_file = component_dir / PYTHON_PACKAGES_ZIP

    python_packages_folder.mkdir(exist_ok=True)

    if packages_file.is_file():
        with zipfile.ZipFile(packages_file) as zip_file:
            zip_file.extractall(python_packages_folder)
        packages_file.unlink()

    command_line = [
        sys.executable, "-m", "pip", "download",
        "-r", f"{requirements_file_path}",
        "-d", f"{python_packages_folder}",
        "--find-links", f"{python_packages_folder}",
        "--python-version", f"{python_version}",
        "--only-binary=:all:", "--no-binary=:none:"
    ]
    for platform in _PLATFORMS:
        command_line += ["--platform", platform]

    result = subprocess.run(command_line, text=True, stderr=subprocess.PIPE)
    if result.returncode != 0:
        raise RuntimeError(result.stderr)

    if any(Path(python_packages_folder).iterdir()):
        shutil.make_archive(
            base_name=str(component_dir / 'PythonPackages'),
            format='zip',
            root_dir=python_packages_folder,
            verbose=True,
            logger=_logger)

    shutil.rmtree(python_packages_folder)


def _generate_runtime_config(pipeline_config: dict):
    project_name = pipeline_config["dataFlowPipelineInfo"]["projectName"]

    return {
        "fileFormatVersion": "1",
        "runtimeInfo": {
            "projectName": project_name,
            "runtimeConfigurationVersion": "1.0.0",
            "createdOn": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        },
        "runtimeConfiguration": {
            "devices": [{
                "name": "IED1",
                "address": "localhost",  # Optional
                "targetProcessor": "CPU",  # Optional
                "arch": "x86_64",  # Optional, TODO: validate target keys
            }],
            "components": [],
        },
    }


def _validate_with_schema(name: str, data: dict, schema: str):
    try:
        jsonschema.validate(
            instance=data,
            schema=json.load(module_resources.open_text("simaticai.data.schemas", schema))
            # TODO: after upgrading to python 3.9
            # schema=json.load(resources.files("simaticai") / "data" / "schemas" / "pipeline.schema.json")
        )
    except jsonschema.exceptions.ValidationError as e:
        raise AssertionError(f"""Schema validation failed for {name} using '{schema}'!
    message: {e.message}
    $id: {e.schema['$id']}
    title: {e.schema['title']}
    description: {e.schema['description']}
    """) from None


def _get_pipeline_info(pipeline_config: str):
    pipeline_config = yaml_helper.read_yaml(pipeline_config)
    pipeline_info = pipeline_config["dataFlowPipelineInfo"]
    pipeline_info["packageType"] = pipeline_config.get("packageType", "full")
    pipeline_info["originVersion"] = pipeline_config.get("originVersion", None)
    return pipeline_info


def _validate_delta_package_inputs(origin_package_info: dict, new_package_info: dict):
    if origin_package_info["packageType"] == "delta" or new_package_info["packageType"] == "delta":
        raise AssertionError("Neither of the packages can be delta package!")

    if origin_package_info["projectName"] != new_package_info["projectName"]:
        raise AssertionError("The new edge package must have the same name as the origin edge package!")

    if origin_package_info["dataFlowPipelineVersion"] == new_package_info["dataFlowPipelineVersion"]:
        raise AssertionError("The new edge package can not have the same version as the origin edge package!")


def _change_pipeline_config(config_path: str, origin_package_version: str):
    data = yaml_helper.read_yaml(config_path)
    data["packageType"] = "delta"
    data["originVersion"] = origin_package_version
    with open(config_path, "w") as f:
        yaml.dump(data, f)


def _extract_edge_package(edge_package_zip_path: str, path_to_extract: Path):
    zipfile.ZipFile(edge_package_zip_path).extractall(path_to_extract)
    for f in path_to_extract.rglob("*.zip"):
        component_path = path_to_extract / "components" / f.stem
        packages = Path(component_path, PYTHON_PACKAGES_ZIP)

        zipfile.ZipFile(f).extractall(component_path)
        if packages.is_file():
            zipfile.ZipFile(component_path / PYTHON_PACKAGES_ZIP).extractall(component_path / "PythonPackages")
            os.remove(packages)
        os.remove(f)
    return path_to_extract


def _copy_file(file_path: Path, from_dir: Path, to_dir: Path):
    new_path = to_dir / file_path.relative_to(from_dir)
    new_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy(file_path, to_dir / file_path.relative_to(from_dir))


def create_delta_package(origin_edge_package_zip_path: str, new_edge_package_zip_path: str):
    """
    Creates a Delta Edge Configuration Package from two given Edge Configuration Packages.
    The created Delta Configuration Package is applicable to import into AI Inference Server,
    if the Original Edge Configuration Package is already imported there.
    The Delta Configuration Package only contains the additions and modifications
    in the New Edge Configuration Package compared to the Original one.
    That also means that no file deletion is possible in a deployed pipeline via this option.
    Please make sure that both of the given zip files come from a trusted source!

    Usage:
    ~~~python
    delta_package_path = deployment.create_delta_package('Edge-Config-edge-1.0.0.zip', 'Edge-Config-edge-1.1.0.zip')
    ~~~

    This method can be used from the command line, too.
    ```
    python -m simaticai create_delta_package <origin_package.zip> <modified_package.zip>
    ```

    Once the package is calculated, you will have an `Edge-Config-edge-delta-1.1.0.zip` file beside the updated package zip file.
    <ul>This package will contain
    <li><ul>the three configuration file for the package;
        <li>pipeline_config.yml</li>
        <li>runtime_config.yml</li>
        <li>datalink_metadata.yml</li>
    </li></ul>
    <li>the newly added files,</li>
    <li>and the updated files.</li>
    </ul>

    The package will not contain any information on the deleted files and they will be copied from the original pipeline.

    **Caution!**
    *If you change the version of a component in the pipeline, the delta package will contain all the files of the component because AI Inference Server identifies
    a component with a different version as a different component!*

    Args:
        origin_edge_package_zip_path (str): Path to the origin edge configuration package zip file.
        new_edge_package_zip_path (str): Path to the new edge configuration package zip file.

    Returns:
        os.PathLike: The path of the created delta edge package zip file.

    Raises:

        AssertionError:
            When:
            - either of the given edge packages is a delta package or
            - the names of the given edge packages differ or
            - the versions of the given edge packages are equal.
    """

    workdir = Path(tempfile.mkdtemp(prefix="aisdk_deltapack-"))
    delta_dir  = Path(workdir / "delta")
    delta_dir.mkdir(parents=True)

    origin_dir = _extract_edge_package(origin_edge_package_zip_path, Path(workdir / "orig"))
    new_dir    = _extract_edge_package(new_edge_package_zip_path, Path(workdir / "new"))

    origin_package_info = _get_pipeline_info(origin_dir / PIPELINE_CONFIG)
    new_package_info = _get_pipeline_info(new_dir / PIPELINE_CONFIG)

    _validate_delta_package_inputs(origin_package_info, new_package_info)

    files_in_new_package = new_dir.rglob("*")
    for f in files_in_new_package:
        if f.is_dir():
            continue
        orig_file_path = origin_dir / f.relative_to(new_dir)
        if not orig_file_path.exists():
            _copy_file(f, new_dir, delta_dir)
        else:
            checksum_original = hashlib.sha256(open(orig_file_path,'rb').read()).hexdigest()
            checksum_new = hashlib.sha256(open(f,'rb').read()).hexdigest()
            if checksum_original != checksum_new:
                _copy_file(f, new_dir, delta_dir)

    _change_pipeline_config(delta_dir / PIPELINE_CONFIG, origin_package_info["dataFlowPipelineVersion"])

    new_edge_package_zip_path = Path(new_edge_package_zip_path)
    delta_path = _zip_delta_package(delta_dir, new_edge_package_zip_path)

    shutil.rmtree(workdir, ignore_errors=True)
    return Path(delta_path)

def _zip_delta_package(delta_dir: Path, new_package_path: Path):
    target_folder = new_package_path.parent
    splitted_name = str(new_package_path.stem).split("_")
    target_name = "_".join(splitted_name[:-1]) + "_delta_" + "".join(splitted_name[-1:])

    for dir in Path(delta_dir / "components").glob("*"):
        if Path(dir / "PythonPackages").is_dir():
            shutil.make_archive(dir / "PythonPackages", "zip", dir / "PythonPackages")
            shutil.rmtree(dir / "PythonPackages")
        shutil.make_archive(dir, "zip", dir)
        shutil.rmtree(dir)

    delta_path = shutil.make_archive(target_folder / target_name, "zip", delta_dir)
    return delta_path


class PipelinePage(markup.page):

    def __init__(self, pipeline: Pipeline):
        super().__init__('strict_html', 'lower')

        self.twotags.append("section")
        self.init(
            title=f"{pipeline.name} ({pipeline.version})",
            doctype="<!DOCTYPE html>",
            charset="utf-8",
            lang="en")

        self.section()

        self.h1(f"Pipeline {pipeline.name} ({pipeline.version})")
        if pipeline.desc:
            self.p(pipeline.desc)
        self.html_generate_parameters(pipeline)
        self.html_generate_pipeline_inputs(pipeline)
        self.html_generate_pipeline_outputs(pipeline)
        self.html_generate_io_wiring(pipeline)
        self.html_generate_timeshifting(pipeline)

        for component in pipeline.components.values():
            self.html_generate_components(component)

        self.section.close()

    def html_generate_components(self, component: Component):
        self.hr()
        self.section()

        self.h1(f"{component.__class__.__name__} {component.name}")
        if component.desc:
            self.p(component.desc)
        self.html_generate_component_inputs(component)
        self.html_generate_component_outputs(component)
        self.html_generate_metrics(component)
        self.html_generate_resources(component)
        self.html_generate_entrypoints(component)

        self.section.close()

    def html_generate_parameters(self, pipeline: Pipeline):
        if len(pipeline.parameters) > 0:
            self.strong("Parameters")
            self.ul()

            for name, parameter in pipeline.parameters.items():
                self.li()
                self.i(f"{name} ({parameter['type']}, default: '{parameter['defaultValue']}')")
                self.br()
                if parameter.get('desc') is not None:
                    self.span(parameter['desc'])
                self.li.close()

            self.ul.close()

    def html_generate_pipeline_inputs(self, pipeline: Pipeline):
        if len(pipeline.inputs) > 0:
            self.strong("Inputs")
            self.ul()

            for component, name in pipeline.inputs:
                input = pipeline.components[component].inputs[name]
                self.li()
                self.i(f"{name} ({input['type']})")
                self.br()
                if input.get('desc') is not None:
                    self.span(input['desc'])
                self.li.close()
            self.ul.close()

    def html_generate_pipeline_outputs(self, pipeline: Pipeline):
        if len(pipeline.outputs) > 0:
            self.strong("Outputs")
            self.ul()

            for component, name in pipeline.outputs:
                output = pipeline.components[component].outputs[name]
                self.li()
                self.i(f"{name} ({output['type']})")
                self.br()
                if output.get('desc') is not None:
                    self.span(output['desc'])
                self.li.close()

            self.ul.close()

    def html_generate_component_inputs(self, component: Component):
        self.strong("Inputs")
        self.ul()

        for name, input in component.inputs.items():
            self.li()
            self.i(f"{name} ({input['type']})")
            self.br()
            if input.get('desc') is not None:
                self.span(input['desc'])
            self.li.close()

        self.ul.close()

    def html_generate_component_outputs(self, component: Component):
        self.strong("Outputs")
        self.ul()

        for name, output in component.outputs.items():
            self.li()
            self.i(f"{name} ({output['type']})")
            self.br()
            if output.get('desc') is not None:
                self.span(output['desc'])
            self.li.close()

        self.ul.close()

    def html_generate_io_wiring(self, pipeline: Pipeline):
        if len(pipeline.wiring) > 0:
            self.strong("I/O Wiring")
            self.ul()

            for component, name in pipeline.inputs:
                self.li(f"{name} &#8594 {component}.{name}")
            for wire_hash in pipeline.wiring:
                self.li(wire_hash.replace("->", "&#8594"))
            for component, name in pipeline.outputs:
                self.li(f"{component}.{name} &#8594 {name}")

            self.ul.close()

    def html_generate_timeshifting(self, pipeline: Pipeline):
        if pipeline.periodicity is not None:
            self.strong("Timeshifting")
            self.ul()
            self.li(f"Periodicity: {pipeline.periodicity} ms")
            self.ul.close()

            if len(pipeline.timeshift_reference) > 0:
                self.strong("References")
                self.ul()
                for ref in pipeline.timeshift_reference:
                    self.li(ref)
                self.ul.close()

    def html_generate_resources(self, component: Component):
        if component.resources is not None and len(component.resources) > 0:
            self.strong("Resources")
            self.ul()
            for path, base in component.resources.items():
                self.li(f"{base}/{path.name}".replace('./', ''))
            self.ul.close()

    def html_generate_entrypoints(self, component: Component):
        if component.entrypoint is not None:
            self.strong("Entrypoint")
            self.ul()
            self.li(component.entrypoint.name)
            self.ul.close()

    def html_generate_metrics(self, component: Component):
        if component.metrics is not None and len(component.metrics) > 0:
            self.strong("Metrics")
            self.ul()
            for name, metric in component.metrics.items():
                self.li()
                self.i(name)
                if metric.get('desc') is not None:
                    self.br()
                    self.span(metric['desc'])
                self.li.close()
            self.ul.close()
