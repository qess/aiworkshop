
import glob
import shutil
import os
from pathlib import Path;
from tensorflow.keras.models import load_model;
import tensorflow as tf2;
path = '/content/'

os.chdir(path+'src/notebooks')
import os
print(os.getcwd())  


print("Conversion started, please wait...")

net = glob.glob(path+'*.h5')
model=load_model(Path(net[0]), compile=False);

converter = tf2.lite.TFLiteConverter.from_keras_model(model);
tflite_model = converter.convert(); #convert to TF lite
with open('../models/classification_mobilnet.tflite', 'wb') as f:
  f.write(tflite_model);



#30c-CreatePipelinePackageZMQ
from simaticai import deployment;



#Create a single component
COMPONENT_DESCRIPTION ="""\
This component uses a trained TensorFlow Lite image classification model that reads a binary object input and produces a prediction as an output.
"""
INPUT_DESCRIPTION ="""
Vision connector MQTT payload holding the image to be classified.
"""
OUTPUT_DESCRIPTION ="""
The most probable class predicted for the image as an integer string.
"""


component = deployment.PythonComponent(name='inference', desc=COMPONENT_DESCRIPTION, version='1.0.0', python_version='3.8')
component.add_resources('..', 'entrypoint.py')
component.set_entrypoint('entrypoint.py')
component.add_resources('..', ['src/payload.py', 'src/vision_classifier_tflite.py'])
component.add_input('vision_payload', 'String', INPUT_DESCRIPTION)
component.add_output('prediction', 'String', OUTPUT_DESCRIPTION)

#
#component.add_resources('..', ['entrypoint_zmq.py', 'src/payload.py', 'src/vision_classifier_tflite.py'])
#


#Add metrics
component.add_metric("ic_probability");

#Add dependencies
component.add_python_packages("../packages/PythonPackages.zip")
component.set_requirements("../runtime_requirements_tflite.txt")

#Add a model
#component.add_resources('..', 'models/classification_mobilnet.h5')
component.add_resources('..', 'models/classification_mobilnet.tflite')


#Create a pipeline from this component
PIPELINE_DESCRIPTION ="""\
This pipeline runs a TensorFlow model on an Industrial Edge device.
The model was trained to recognize and classify images of following Siemens SIMATIC automation products: ET 200AL, ET 200eco PN, ET 200SP, S7-1200, S7-1500.

The pipeline is designed to be fed from Vision Connector via Databus with PNG or JPEG type images.
The pipeline output is to be sent to the Databus.
"""

name='Image_on_Edge_package'
version='1.0.0'

pipeline = deployment.Pipeline.from_components([component], name=name, desc=PIPELINE_DESCRIPTION, version='1.0.0')

#Build the pipeline configuration package
pipeline_package_path = pipeline.save('../packages')

#Build the edge configuration package
deployment.convert_package(pipeline_package_path);

#Copy to folder

shutil.copyfile( path +'src/packages/'+name+'-edge_'+version+'.zip', path + name +'-edge_'+version+'.zip')

print("Conversion complete. You may now close this tab.")